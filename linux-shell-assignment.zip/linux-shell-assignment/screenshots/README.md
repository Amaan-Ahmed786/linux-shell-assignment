# Screenshots

Place your terminal screenshots here (e.g., `backup_success.png`, `monitor_log.png`, `download_complete.png`).
